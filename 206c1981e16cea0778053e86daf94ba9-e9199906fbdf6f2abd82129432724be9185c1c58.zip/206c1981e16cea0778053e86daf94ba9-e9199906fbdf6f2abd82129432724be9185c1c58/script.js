document.getElementById("footer-button").onclick = function() {
    window.location.href = "https://discord.gg/zeon";
}
document.getElementById("footer-text").onclick = function() {
    window.location.href = "buraya_linkinizi_girin";
}
